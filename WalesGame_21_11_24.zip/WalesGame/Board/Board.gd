extends Spatial


# Declare member variables here. Examples:
# var a: int = 2
# var b: String = "text"
var _cursor = Vector2(0, 0)
var _step = Vector2(1, 0)

var _card_scene = load("res://Card/Card.tscn")

func get_card(var which):
	return get_child(which)


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	
	add_card(Globals.eCard.CARD_LAKE, "Clywedog Reservoir")
	add_card(Globals.eCard.CARD_LAKE, "Elan Valley")
	add_card(Globals.eCard.CARD_LAKE, "Llyn Brianne")
	add_card(Globals.eCard.CARD_LAKE, "Lake Vyrnwy")
	add_card(Globals.eCard.CARD_LAKE, "Llyn Tegid")
	add_card(Globals.eCard.CARD_LAKE, "Llyn Ogwen")
	add_card(Globals.eCard.CARD_LAKE, "Llyn Celyn")
	add_card(Globals.eCard.CARD_LAKE, "Glaslyn")
	step(0, -1)
	add_card(Globals.eCard.CARD_LAKE, "Llyn Padarn")
	add_card(Globals.eCard.CARD_LAKE, "Llangorse Lake")
	add_card(Globals.eCard.CARD_LAKE, "Llyn Trawsfrnydd")
	add_card(Globals.eCard.CARD_MOUNTAIN, "Snowdon")
	add_card(Globals.eCard.CARD_MOUNTAIN, "Cadair Idris")
	add_card(Globals.eCard.CARD_MOUNTAIN, "Pen y Fan")
	add_card(Globals.eCard.CARD_MOUNTAIN, "Aran Fawddwy")
	step(1, 0)
	add_card(Globals.eCard.CARD_MOUNTAIN, "Penygader")
	add_card(Globals.eCard.CARD_MOUNTAIN, "Moel Hebog")
	add_card(Globals.eCard.CARD_MOUNTAIN, "Moel Siabod")
	add_card(Globals.eCard.CARD_CASTLE, "Montgomery")
	add_card(Globals.eCard.CARD_CASTLE, "Harlech")
	step(0, -1)
	add_card(Globals.eCard.CARD_CASTLE, "Picton")
	add_card(Globals.eCard.CARD_CASTLE, "Skenfrith")
	add_card(Globals.eCard.CARD_CASTLE, "Pembroke")
	add_card(Globals.eCard.CARD_CASTLE, "Powis")
	step(-1, 0)
	add_card(Globals.eCard.CARD_CASTLE, "Chirk")
	add_card(Globals.eCard.CARD_CASTLE, "Dinefwr")
	add_card(Globals.eCard.CARD_CASTLE, "Conwy")
	add_card(Globals.eCard.CARD_CASTLE, "Caernarfon")
	add_card(Globals.eCard.CARD_CASTLE, "Criccieth")
	add_card(Globals.eCard.CARD_CASTLE, "Chepstow")
	add_card(Globals.eCard.CARD_CASTLE, "Cardiff")
	add_card(Globals.eCard.CARD_FOREST, "Hafren")
	add_card(Globals.eCard.CARD_FOREST, "Coed y Brenin")
	add_card(Globals.eCard.CARD_FOREST, "Brechfa")
	step(0, 1)
	add_card(Globals.eCard.CARD_FOREST, "Penllyn")
	add_card(Globals.eCard.CARD_FOREST, "Dyfnant")
	add_card(Globals.eCard.CARD_FOREST, "Gwydir")
	add_card(Globals.eCard.CARD_FOREST, "Giedd")
	add_card(Globals.eCard.CARD_LAKE, "Aber Falls")
	add_card(Globals.eCard.CARD_LAKE, "Rhaeadr Y Graid Lwyd")
	add_card(Globals.eCard.CARD_LAKE, "Swallow Falls")
	add_card(Globals.eCard.CARD_LAKE, "Henrhyd Falls")
	add_card(Globals.eCard.CARD_LAKE, "Dolgoch Falls")
	add_card(Globals.eCard.CARD_LAKE, "Pistyll Rhaeadr")
	
	Globals._num_cards = get_child_count()
	
	pass # Replace with function body.

func step(var x, var y):
	_step = Vector2(x, y)

func add_card(var type, var name):
	var card : Spatial
	card = _card_scene.instance()
	
	
	card.setup(type, name)
	card.transform.origin = Vector3(_cursor.x, 0, _cursor.y)
	add_child(card)
	_cursor += (_step * 2)

		

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta: float) -> void:
#	pass
