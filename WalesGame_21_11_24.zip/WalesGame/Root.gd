extends Spatial


# Declare member variables here. Examples:
# var a: int = 2
# var b: String = "text"

var _curr_player
var _curr_player_id : int = 0
var _num_players : int = 0


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	
	$Property.hide()
	
	var p = load("res://Player/Player.tscn")
	_num_players = 2
	
	var stats_scene = load("res://Player/PlayerStat.tscn")
	
	for i in range (_num_players):
		var play = p.instance()
		$Players.add_child(play)
		play.set_id(i)
		
		var ss = stats_scene.instance()
		ss.setup(i)
		$PlayerStats/VSplitContainer.add_child(ss)
	
	_curr_player_id = -1
	change_player()
	
	Globals._board = $Board
	Globals._root = self
	
	make_move()
	pass # Replace with function body.


func change_player():
	_curr_player_id += 1
	_curr_player_id %= _num_players
	_curr_player = get_player(_curr_player_id)

func get_player(id):
	return $Players.get_child(id)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	
	#if _curr_player:
	#	return
		
	#rocess_input()
	pass

func process_input():
	if Input.is_action_just_pressed("ui_accept") and (_curr_player._moving == false):
		make_move()

func make_move():
	print("make move")
	
	# roll dice
	var steps = (randi() % 6) + 1
	
	$Info.info("Rolled " + str(steps))
	
	_curr_player.make_move(steps)
	
	

func reached_target():
	print("Reached target")
	var card = _curr_player.get_current_card()
	
	var available = false
	if (card._owner == -1):
		available = true
		
	$Property/VSplitContainer/HSplitContainer/Button_Buy.visible = available
	
	var owned = (available == false) && (card._owner == _curr_player_id)
	
	$Property/VSplitContainer/HSplitContainer/Button_Sell.visible = owned
	
	var pay = !available && !owned
	
	if pay:
		_curr_player.change_cash(-card._rent)
		get_player(card._owner).change_cash(card._rent)
		$Info.info("Paid rent " + str(card._rent) + " to Player " + str(card._owner))
	
	
	$Property/VSplitContainer/Label.text = card._name
		
	$Property.show()
	


func _on_Button_Buy_pressed():
	_curr_player.buy_property()
	update_player_stats()
	$Property.hide()
	change_player()
	make_move()
	pass # Replace with function body.


func _on_Button_Sell_pressed():
	$Property.hide()
	change_player()
	make_move()
	pass # Replace with function body.


func _on_Button_NoAction_pressed():
	$Property.hide()
	change_player()
	make_move()
	pass # Replace with function body.

func update_player_stats():
	for n in range (0, $PlayerStats/VSplitContainer.get_child_count()):
		var ps = $PlayerStats/VSplitContainer.get_child(n)
		ps.update_stats()
