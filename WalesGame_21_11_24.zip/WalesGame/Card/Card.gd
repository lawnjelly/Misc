extends MeshInstance

var _owner : int = -1
var _name : String = "unnamed"
var _cost : int = 100
var _rent : int = 20

func _ready() -> void:
	pass # Replace with function body.

func set_player_owner(var owner:int):
	_owner = owner

func setup(var type, var name, var cost = 100):
	set_name(name)
	$Name.text = name
	_name = name
	_cost = cost
	
	_rent = int(_cost / 10.0)
	
	match type:
		Globals.eCard.CARD_LAKE:
			set_material_override(Globals._mat_lake)
			pass
		Globals.eCard.CARD_CASTLE:
			set_material_override(Globals._mat_castle)
			pass
		Globals.eCard.CARD_FOREST:
			set_material_override(Globals._mat_forest)
			pass
		Globals.eCard.CARD_MOUNTAIN:
			set_material_override(Globals._mat_mountain)
			pass
