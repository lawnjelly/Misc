extends Spatial


# Declare member variables here. Examples:
# var a: int = 2
# var b: String = "text"

var _timeout = 0
var _tick = 0


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _physics_process(_delta: float) -> void:
	_tick += 1
	
	if (_timeout != 0) and (_tick > _timeout):
		$Label.visible = false
	pass

func info(var s):
	$Label.text = s
	$Label.visible = true
	_timeout = _tick + 10
	print(s)
