extends Spatial


# Declare member variables here. Examples:
# var a: int = 2
# var b: String = "text"
var _target_pos : Vector3
var _next_target_tile : int = 0
var _moving : bool = false
var _tile : int = 0
var _player_id : int = -1

var _cash : int = 2000

func set_id(var which):
	for n in get_child_count():
		get_child(n).visible = false

	get_child(which).visible = true
	
	_player_id = which

func _increment_target_tile()->bool:
	if _next_target_tile == _tile:
		return false
	
	_next_target_tile += 1
	_next_target_tile = _next_target_tile % Globals._num_cards
	
	var card = Globals._board.get_card(_next_target_tile)
	_target_pos = card.get_global_transform().origin
	
	return true
		
func get_current_card():
	var card = Globals._board.get_card(_tile)
	return card
	
func can_buy_property()->bool:
	return _cash >= get_current_card()._cost
	
func change_cash(change : int)->bool:
	_cash += change
	return _cash >= 0
	
func buy_property():
	var card = get_current_card()
	card.set_player_owner(_player_id)
	change_cash(-card._cost)
	pass
		
func make_move(num_steps : int):
	_tile += num_steps
	_tile = _tile % Globals._num_cards
	_moving = true
	
	#var card = Globals._board.get_card(_tile)
	#_target_pos = card.get_global_transform().origin

func _physics_process(_delta: float) -> void:
	
	# nothing to do
	if _moving == false:
		return
	

	var pos = get_global_transform().origin
	var offset = _target_pos - pos
	var l = offset.length()
	
	if (l > 1):
		offset = offset.normalized() * 1
	else:
		if _increment_target_tile() == false:
			_moving = false
			Globals._root.reached_target()

	pos += offset
	translation = pos
	
	
	pass
	
	
