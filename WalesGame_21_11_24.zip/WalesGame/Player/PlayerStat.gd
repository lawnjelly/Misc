extends HSplitContainer


# Declare member variables here. Examples:
# var a = 2
# var b = "text"
var _player_id = 0


# Called when the node enters the scene tree for the first time.
func _ready():
	pass # Replace with function body.

func setup(var id):
	_player_id = id
	$Label_Name.text = "Player " + str(id)

# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta):
#	pass

func update_stats():
	var player = Globals._root.get_player(_player_id)
	$Label_Cash.text = str(player._cash)
