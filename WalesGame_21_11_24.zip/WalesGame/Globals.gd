extends Node


# Declare member variables here. Examples:
# var a: int = 2
# var b: String = "text"

var _board
var _root

var _num_cards : int = 0

var _mat_castle = load("res://Card/Materials/Mat_Card_Castle.tres")
var _mat_forest = load("res://Card/Materials/Mat_Card_Forest.tres")
var _mat_lake = load("res://Card/Materials/Mat_Card_Lake.tres")
var _mat_mountain = load("res://Card/Materials/Mat_Card_Mountain.tres")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
#func _process(delta: float) -> void:
#	pass

enum eCard {
	CARD_FOREST,
	CARD_LAKE,
	CARD_CASTLE,
	CARD_MOUNTAIN,
	CARD_NUM_TYPES,
}
